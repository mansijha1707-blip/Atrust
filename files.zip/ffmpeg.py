"""
ffmpeg.py – FFmpeg helpers for Atrust.
Used by the video/audio analysers to extract frames and audio streams.
Install ffmpeg: https://ffmpeg.org/download.html

These are stubs ready for real implementation.
"""

import subprocess
from pathlib import Path


def extract_frames(video_path: Path, output_dir: Path, fps: int = 1) -> list[Path]:
    """
    Extract frames from a video at `fps` frames per second.
    Returns a list of extracted frame paths.

    Real implementation:
        ffmpeg -i video.mp4 -vf fps=1 output_dir/frame_%04d.jpg
    """
    # ── Stub: return empty list until ffmpeg is configured ──────────────────
    output_dir.mkdir(parents=True, exist_ok=True)
    # Uncomment when ffmpeg is installed:
    # cmd = [
    #     "ffmpeg", "-i", str(video_path),
    #     "-vf", f"fps={fps}",
    #     str(output_dir / "frame_%04d.jpg"),
    #     "-hide_banner", "-loglevel", "error",
    # ]
    # subprocess.run(cmd, check=True)
    # return sorted(output_dir.glob("frame_*.jpg"))
    return []


def extract_audio(video_path: Path, output_path: Path) -> Path:
    """
    Extract the audio track from a video file.
    Returns path to the extracted .wav file.

    Real implementation:
        ffmpeg -i video.mp4 -vn -acodec pcm_s16le -ar 44100 audio.wav
    """
    # ── Stub ────────────────────────────────────────────────────────────────
    # Uncomment when ffmpeg is installed:
    # cmd = [
    #     "ffmpeg", "-i", str(video_path),
    #     "-vn", "-acodec", "pcm_s16le", "-ar", "44100",
    #     str(output_path),
    #     "-hide_banner", "-loglevel", "error",
    # ]
    # subprocess.run(cmd, check=True)
    return output_path


def get_video_duration(video_path: Path) -> float:
    """Return video duration in seconds using ffprobe."""
    # Uncomment when ffmpeg is installed:
    # result = subprocess.run(
    #     ["ffprobe", "-v", "error", "-show_entries", "format=duration",
    #      "-of", "default=noprint_wrappers=1:nokey=1", str(video_path)],
    #     capture_output=True, text=True
    # )
    # return float(result.stdout.strip())
    return 0.0
