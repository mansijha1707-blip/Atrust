"""
report.py – Report generation helpers for Atrust.
Formats analysis results into structured reports (dict / JSON / PDF-ready).
"""

from datetime import datetime, timezone
from typing import Any


def build_report(endpoint: str, filename: str, result: dict) -> dict:
    """
    Wrap an analysis result dict with metadata for a full report.
    This dict can be serialised to JSON or passed to a PDF renderer.
    """
    return {
        "report": {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "endpoint":     endpoint,
            "filename":     filename,
            "verdict":      result.get("status"),
            "confidence":   result.get("confidence"),
            "summary":      result.get("summary"),
            "details":      result.get("details", {}),
        }
    }


def risk_label(confidence: float, threshold_high: float = 0.80, threshold_medium: float = 0.55) -> str:
    """Map a confidence score to a human-readable risk label."""
    if confidence >= threshold_high:
        return "HIGH"
    if confidence >= threshold_medium:
        return "MEDIUM"
    return "LOW"


def format_text_report(result: dict) -> str:
    """Return a plain-text summary of an analysis result."""
    lines = [
        f"Atrust Analysis Report — {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        f"Verdict    : {result.get('status', 'unknown').upper()}",
        f"Confidence : {result.get('confidence', 0):.1%}",
        f"Risk Level : {risk_label(result.get('confidence', 0))}",
        f"Summary    : {result.get('summary', '')}",
        "",
        "Details:",
    ]
    for k, v in result.get("details", {}).items():
        lines.append(f"  {k}: {v}")
    return "\n".join(lines)
