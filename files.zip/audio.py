"""
audio.py – Voice cloning / audio manipulation detection for Atrust.

Stub implementation: returns realistic mock results.
Plug in your real model in detect_voice_clone() below.

Suggested real models:
  - RawNet2
  - AASIST (Audio Anti-Spoofing using Integrated Spectro-Temporal)
  - Resemblyzer (speaker verification)
  - WaveFake detector
"""

import random
from pathlib import Path
from fastapi import APIRouter, File, UploadFile, BackgroundTasks, HTTPException

from files import save_upload, schedule_delete, ALLOWED_AUDIO_TYPES
from schemas import AudioAnalysisResponse, AudioDetails

router = APIRouter()


# ── Core detector ──────────────────────────────────────────────────────────────

def detect_voice_clone(path: Path) -> dict:
    """
    Analyse an audio file for voice cloning or audio manipulation.

    Args:
        path: Path to the locally saved audio file.

    Returns:
        dict with keys: status, confidence, summary, details
    """
    # ══════════════════════════════════════════════════════
    # PLUG YOUR REAL MODEL IN HERE
    # Example (RawNet2):
    #   from your_model import RawNet2Classifier
    #   model = RawNet2Classifier.load("weights/rawnet2.pt")
    #   score = model.predict(str(path))   # float 0–1 (1 = spoof)
    #   is_cloned = score > 0.5
    # ══════════════════════════════════════════════════════

    confidence = round(random.uniform(0.60, 0.99), 4)
    is_cloned = confidence > 0.77

    spectral  = round(random.uniform(0.50, 0.95) if is_cloned else random.uniform(0.03, 0.28), 4)
    prosody   = round(random.uniform(0.40, 0.90) if is_cloned else random.uniform(0.02, 0.25), 4)
    bg_noise  = round(random.uniform(0.20, 0.75) if is_cloned else random.uniform(0.00, 0.20), 4)
    voice_sim = round(random.uniform(0.60, 0.98) if is_cloned else random.uniform(0.10, 0.40), 4)

    return {
        "status": "cloned" if is_cloned else "authentic",
        "confidence": confidence,
        "summary": (
            "Audio exhibits spectral artefacts, prosody mismatches, and voice-clone signatures — "
            "high likelihood of TTS or voice-cloning software."
            if is_cloned else
            "No voice-cloning or audio manipulation artefacts detected. Audio appears authentic."
        ),
        "details": {
            "spectral_anomaly":               spectral,
            "prosody_mismatch":               prosody,
            "background_noise_inconsistency": bg_noise,
            "voice_similarity_score":         voice_sim,
        },
    }


# ── Route ──────────────────────────────────────────────────────────────────────

@router.post("", response_model=AudioAnalysisResponse)
async def analyze_audio(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="MP3, WAV, OGG, or M4A audio file"),
):
    """
    Upload and analyse an audio clip for voice cloning or manipulation.

    - Accepts: `multipart/form-data` with field name `file`
    - Returns: verdict, confidence score, and per-feature breakdown
    - The uploaded file is deleted automatically after analysis
    """
    if file.content_type not in ALLOWED_AUDIO_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{file.content_type}'. Accepted: {sorted(ALLOWED_AUDIO_TYPES)}",
        )

    path = await save_upload(file)
    schedule_delete(path, background_tasks)

    result = detect_voice_clone(path)
    return AudioAnalysisResponse(
        filename=file.filename,
        details=AudioDetails(**result["details"]),
        **{k: v for k, v in result.items() if k != "details"},
    )
