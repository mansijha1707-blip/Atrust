"""
schemas.py – Pydantic response models for all Atrust endpoints.
All analysis responses share a common base; each modality extends it
with its own detail fields.
"""

from pydantic import BaseModel, Field
from typing import Literal, List, Optional


# ── Shared ─────────────────────────────────────────────────────────────────────

class BaseAnalysisResponse(BaseModel):
    filename:   Optional[str] = None
    status:     str           = Field(..., description="Primary verdict, e.g. 'fake', 'authentic', 'phishing'")
    confidence: float         = Field(..., ge=0.0, le=1.0, description="Model confidence 0–1")
    summary:    str           = Field(..., description="Human-readable verdict summary")


# ── Upload ─────────────────────────────────────────────────────────────────────

class UploadResponse(BaseModel):
    message:      str
    filename:     str
    file_id:      str
    content_type: str
    size_bytes:   int


# ── Video ──────────────────────────────────────────────────────────────────────

class VideoDetails(BaseModel):
    facial_inconsistency:  float
    temporal_artifacts:    float
    lip_sync_mismatch:     float
    frame_anomaly_score:   float

class VideoAnalysisResponse(BaseAnalysisResponse):
    endpoint: Literal["analyze/video"] = "analyze/video"
    details:  VideoDetails


# ── Image ──────────────────────────────────────────────────────────────────────

class ImageDetails(BaseModel):
    face_swap_probability:  float
    noise_pattern_anomaly:  float
    metadata_tampering:     float
    gan_fingerprint_score:  float

class ImageAnalysisResponse(BaseAnalysisResponse):
    endpoint: Literal["analyze/image"] = "analyze/image"
    details:  ImageDetails


# ── Audio ──────────────────────────────────────────────────────────────────────

class AudioDetails(BaseModel):
    spectral_anomaly:                float
    prosody_mismatch:                float
    background_noise_inconsistency:  float
    voice_similarity_score:          float

class AudioAnalysisResponse(BaseAnalysisResponse):
    endpoint: Literal["analyze/audio"] = "analyze/audio"
    details:  AudioDetails


# ── Text ───────────────────────────────────────────────────────────────────────

class TextDetails(BaseModel):
    detected_keywords:   List[str]
    impersonation_risk:  float
    urgency_score:       float
    spam_score:          float

class TextAnalysisResponse(BaseAnalysisResponse):
    endpoint:     Literal["analyze/text"] = "analyze/text"
    input_length: int
    details:      TextDetails
