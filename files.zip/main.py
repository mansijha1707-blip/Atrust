"""
Atrust – Multi-Modal Digital Trust Verification Backend
========================================================
Entry point. Run with:
    uvicorn main:app --reload
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routers import video, image, audio, text, upload

app = FastAPI(
    title="Atrust API",
    description="Multi-Modal Digital Trust Verification — deepfake video, AI image, voice clone & phishing detection.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS ───────────────────────────────────────────────────────────────────────
# Allows your HTML/React frontend running on any localhost port to call the API.
# Restrict allow_origins to your production domain before deploying.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Routers ────────────────────────────────────────────────────────────────────
app.include_router(upload.router, prefix="/upload",        tags=["Upload"])
app.include_router(video.router,  prefix="/analyze/video", tags=["Analysis – Video"])
app.include_router(image.router,  prefix="/analyze/image", tags=["Analysis – Image"])
app.include_router(audio.router,  prefix="/analyze/audio", tags=["Analysis – Audio"])
app.include_router(text.router,   prefix="/analyze/text",  tags=["Analysis – Text"])


# ── Health ─────────────────────────────────────────────────────────────────────
@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "message": "Atrust API is running 🛡️", "version": "1.0.0"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
