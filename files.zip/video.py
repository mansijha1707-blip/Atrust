"""
video.py – Deepfake video detection for Atrust.

Stub implementation: returns realistic mock results.
Plug in your real model in detect_deepfake() below.

Suggested real models:
  - FaceForensics++ (binary classifier)
  - DFDC Kaggle winner models
  - DeepFaceLab detector
  - Xception-based classifiers
"""

import random
from pathlib import Path
from fastapi import APIRouter, File, UploadFile, BackgroundTasks, HTTPException

from files import save_upload, schedule_delete, ALLOWED_VIDEO_TYPES
from schemas import VideoAnalysisResponse, VideoDetails

router = APIRouter()


# ── Core detector (replace body with real model) ───────────────────────────────

def detect_deepfake(path: Path) -> dict:
    """
    Analyse a video file for deepfake manipulation.

    Args:
        path: Path to the locally saved video file.

    Returns:
        dict with keys: status, confidence, summary, details
    """
    # ══════════════════════════════════════════════════════
    # PLUG YOUR REAL MODEL IN HERE
    # Example (FaceForensics++):
    #   from your_model import FaceForensicsClassifier
    #   model = FaceForensicsClassifier.load("weights/ff++.pt")
    #   result = model.predict(str(path))
    #   confidence = result.score
    #   is_fake = result.label == "FAKE"
    # ══════════════════════════════════════════════════════

    confidence = round(random.uniform(0.60, 0.99), 4)
    is_fake = confidence > 0.80

    facial   = round(random.uniform(0.40, 0.98) if is_fake else random.uniform(0.05, 0.35), 4)
    temporal = round(random.uniform(0.35, 0.90) if is_fake else random.uniform(0.03, 0.30), 4)
    lip_sync = round(random.uniform(0.30, 0.85) if is_fake else random.uniform(0.02, 0.25), 4)
    frame    = round(random.uniform(0.40, 0.95) if is_fake else random.uniform(0.05, 0.30), 4)

    return {
        "status": "fake" if is_fake else "authentic",
        "confidence": confidence,
        "summary": (
            "Significant facial inconsistencies, unnatural blinking, and frame-level artefacts detected — "
            "high probability of deepfake manipulation."
            if is_fake else
            "No significant manipulation artefacts found. Video appears authentic."
        ),
        "details": {
            "facial_inconsistency":  facial,
            "temporal_artifacts":    temporal,
            "lip_sync_mismatch":     lip_sync,
            "frame_anomaly_score":   frame,
        },
    }


# ── Route ──────────────────────────────────────────────────────────────────────

@router.post("", response_model=VideoAnalysisResponse)
async def analyze_video(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="MP4, MOV, AVI, or WEBM video file"),
):
    """
    Upload and analyse a video for deepfake manipulation.

    - Accepts: `multipart/form-data` with field name `file`
    - Returns: verdict, confidence score, and per-feature breakdown
    - The uploaded file is deleted automatically after analysis
    """
    if file.content_type not in ALLOWED_VIDEO_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{file.content_type}'. Accepted: {sorted(ALLOWED_VIDEO_TYPES)}",
        )

    path = await save_upload(file)
    schedule_delete(path, background_tasks)

    result = detect_deepfake(path)
    return VideoAnalysisResponse(
        filename=file.filename,
        details=VideoDetails(**result["details"]),
        **{k: v for k, v in result.items() if k != "details"},
    )
