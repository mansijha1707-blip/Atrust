"""
text.py – Phishing / scam text detection for Atrust.

Stub implementation: keyword heuristic with realistic scoring.
Plug in your real NLP model in detect_phishing() below.

Suggested real models:
  - Fine-tuned BERT / RoBERTa on phishing datasets
  - OpenAI Moderation API
  - Google Cloud Natural Language API (Safety)
  - Custom regex + ML pipeline
"""

import re
import random
from fastapi import APIRouter, Form, HTTPException
from schemas import TextAnalysisResponse, TextDetails

router = APIRouter()


# ── Keyword bank ───────────────────────────────────────────────────────────────
# Covers UPI scams, OTP fraud, impersonation, lottery/prize scams common in India

HIGH_RISK_KEYWORDS = [
    # Financial / payment fraud
    "otp", "upi", "neft", "imps", "ifsc", "cvv", "pin",
    "bank account", "account number", "send money", "transfer money",
    "pay now", "payment failed", "transaction blocked",
    # Urgency / pressure tactics
    "urgent", "immediately", "act now", "limited time", "expires today",
    "last chance", "final notice", "within 24 hours",
    # Account / KYC fraud
    "account blocked", "account suspended", "kyc pending", "kyc update",
    "verify your account", "reactivate", "click here to verify",
    # Prize / lottery scams
    "you have won", "lottery", "prize money", "claim your reward",
    "lucky winner", "congratulations you",
    # Impersonation
    "rbi", "income tax department", "irdai", "trai", "narcotics",
    "police case", "fir registered", "arrest warrant",
    # Phishing links
    "click here", "click the link", "visit this link",
    "bit.ly", "tinyurl", "t.me",
]


# ── Core detector ──────────────────────────────────────────────────────────────

def detect_phishing(text: str) -> dict:
    """
    Analyse a text message for phishing, scam, or impersonation content.

    Args:
        text: Raw message string.

    Returns:
        dict with keys: status, confidence, summary, details
    """
    # ══════════════════════════════════════════════════════
    # PLUG YOUR REAL MODEL IN HERE
    # Example (fine-tuned BERT):
    #   from transformers import pipeline
    #   classifier = pipeline("text-classification", model="your-org/phishing-bert")
    #   result = classifier(text)[0]
    #   is_phishing = result["label"] == "PHISHING"
    #   confidence  = result["score"]
    # ══════════════════════════════════════════════════════

    lower = text.lower()
    hits = [kw for kw in HIGH_RISK_KEYWORDS if re.search(r'\b' + re.escape(kw) + r'\b', lower)]

    # Heuristic confidence: base 0.30 + 0.10 per keyword hit, capped at 0.97
    raw_conf = min(0.97, 0.30 + len(hits) * 0.10)
    # Add small random jitter to simulate model variance
    confidence = round(max(0.0, min(1.0, raw_conf + random.uniform(-0.03, 0.03))), 4)

    is_phishing = confidence > 0.58

    impersonation_risk = round(
        random.uniform(0.55, 0.95) if is_phishing else random.uniform(0.05, 0.30), 4
    )
    urgency_score = round(
        random.uniform(0.50, 1.00) if is_phishing else random.uniform(0.05, 0.35), 4
    )
    spam_score = round(
        random.uniform(0.50, 0.95) if is_phishing else random.uniform(0.03, 0.30), 4
    )

    return {
        "status": "phishing" if is_phishing else "safe",
        "confidence": confidence,
        "summary": (
            f"Message contains {len(hits)} high-risk indicator(s): {', '.join(hits[:6])}{'…' if len(hits) > 6 else ''}. "
            "Likely a phishing, scam, or impersonation attempt."
            if is_phishing else
            "No significant phishing or scam indicators detected. Message appears safe."
        ),
        "details": {
            "detected_keywords":  hits,
            "impersonation_risk": impersonation_risk,
            "urgency_score":      urgency_score,
            "spam_score":         spam_score,
        },
    }


# ── Route ──────────────────────────────────────────────────────────────────────

@router.post("", response_model=TextAnalysisResponse)
async def analyze_text(
    text: str = Form(..., description="The message text to analyse for phishing or scam content"),
):
    """
    Analyse a text message for phishing, UPI/OTP scams, or impersonation.

    - Accepts: `multipart/form-data` with field name `text`
    - Also accepts: `application/x-www-form-urlencoded`
    - Returns: verdict, confidence score, and detected indicators
    """
    if not text or not text.strip():
        raise HTTPException(status_code=422, detail="The 'text' field must not be empty.")
    if len(text) > 10_000:
        raise HTTPException(status_code=413, detail="Text too long. Maximum 10,000 characters.")

    result = detect_phishing(text)
    return TextAnalysisResponse(
        filename=None,
        input_length=len(text),
        details=TextDetails(**result["details"]),
        **{k: v for k, v in result.items() if k != "details"},
    )
