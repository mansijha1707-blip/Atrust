"""
files.py – File I/O helpers for Atrust.
Handles saving uploads and scheduling post-analysis cleanup.
"""

import uuid
import aiofiles
from pathlib import Path
from fastapi import UploadFile, BackgroundTasks

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# ── Allowed MIME types ─────────────────────────────────────────────────────────
ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/gif", "image/bmp"}
ALLOWED_VIDEO_TYPES = {"video/mp4", "video/quicktime", "video/x-msvideo", "video/webm", "video/mpeg"}
ALLOWED_AUDIO_TYPES = {"audio/mpeg", "audio/wav", "audio/ogg", "audio/webm", "audio/mp4", "audio/x-wav"}


async def save_upload(file: UploadFile) -> Path:
    """
    Write an UploadFile to UPLOAD_DIR with a unique name.
    Returns the Path of the saved file.
    """
    ext = Path(file.filename).suffix if file.filename else ""
    dest = UPLOAD_DIR / f"{uuid.uuid4().hex}{ext}"
    async with aiofiles.open(dest, "wb") as out:
        while chunk := await file.read(1024 * 1024):   # 1 MB chunks
            await out.write(chunk)
    return dest


def schedule_delete(path: Path, background_tasks: BackgroundTasks) -> None:
    """Queue file deletion to run after the HTTP response is sent."""
    background_tasks.add_task(_delete_file, path)


def _delete_file(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except Exception:
        pass
