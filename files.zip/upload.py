"""
upload.py – Generic file upload endpoint for Atrust.
Accepts any supported media file and saves it to uploads/.
"""

from fastapi import APIRouter, File, UploadFile, HTTPException
from files import save_upload, ALLOWED_IMAGE_TYPES, ALLOWED_VIDEO_TYPES, ALLOWED_AUDIO_TYPES
from schemas import UploadResponse

router = APIRouter()

ALL_ALLOWED = ALLOWED_IMAGE_TYPES | ALLOWED_VIDEO_TYPES | ALLOWED_AUDIO_TYPES


@router.post("", response_model=UploadResponse)
async def upload_file(
    file: UploadFile = File(..., description="Any supported image, video, or audio file"),
):
    """
    Upload a media file.

    The file is saved to uploads/ and a file_id is returned.
    You can use the per-modality /analyze/* endpoints directly — they handle
    upload + analysis in one step and clean up automatically.
    """
    if file.content_type not in ALL_ALLOWED:
        raise HTTPException(
            status_code=415,
            detail=(
                f"Unsupported media type '{file.content_type}'. "
                f"Accepted: {sorted(ALL_ALLOWED)}"
            ),
        )

    path = await save_upload(file)
    return UploadResponse(
        message="File uploaded successfully",
        filename=file.filename or path.name,
        file_id=path.stem,
        content_type=file.content_type,
        size_bytes=path.stat().st_size,
    )
