"""
image.py – AI-generated / manipulated image detection for Atrust.

Stub implementation: returns realistic mock results.
Plug in your real model in detect_ai_image() below.

Suggested real models:
  - CNNDetection (Wang et al.)
  - UniversalFakeDetect
  - Grounding DINO + face-swap classifier
  - DIRE (Diffusion Reconstruction Error)
"""

import random
from pathlib import Path
from fastapi import APIRouter, File, UploadFile, BackgroundTasks, HTTPException

from files import save_upload, schedule_delete, ALLOWED_IMAGE_TYPES
from schemas import ImageAnalysisResponse, ImageDetails

router = APIRouter()


# ── Core detector ──────────────────────────────────────────────────────────────

def detect_ai_image(path: Path) -> dict:
    """
    Analyse an image for AI-generation (GANs, diffusion) or face-swap manipulation.

    Args:
        path: Path to the locally saved image file.

    Returns:
        dict with keys: status, confidence, summary, details
    """
    # ══════════════════════════════════════════════════════
    # PLUG YOUR REAL MODEL IN HERE
    # Example (CNNDetection):
    #   from your_model import CNNDetector
    #   model = CNNDetector.load("weights/cnn_detect.pth")
    #   proba = model.predict(str(path))   # float 0–1
    #   is_fake = proba > 0.5
    #   confidence = proba if is_fake else 1 - proba
    # ══════════════════════════════════════════════════════

    confidence = round(random.uniform(0.60, 0.99), 4)
    is_fake = confidence > 0.78

    face_swap = round(random.uniform(0.50, 0.95) if is_fake else random.uniform(0.02, 0.25), 4)
    noise     = round(random.uniform(0.45, 0.90) if is_fake else random.uniform(0.03, 0.30), 4)
    metadata  = round(random.uniform(0.20, 0.80) if is_fake else random.uniform(0.00, 0.20), 4)
    gan_fp    = round(random.uniform(0.50, 0.98) if is_fake else random.uniform(0.02, 0.28), 4)

    return {
        "status": "ai_generated" if is_fake else "authentic",
        "confidence": confidence,
        "summary": (
            "Image exhibits GAN fingerprints, noise pattern anomalies, and possible face-swap artefacts — "
            "likely AI-generated or manipulated."
            if is_fake else
            "No AI-generation or manipulation indicators detected. Image appears authentic."
        ),
        "details": {
            "face_swap_probability":  face_swap,
            "noise_pattern_anomaly":  noise,
            "metadata_tampering":     metadata,
            "gan_fingerprint_score":  gan_fp,
        },
    }


# ── Route ──────────────────────────────────────────────────────────────────────

@router.post("", response_model=ImageAnalysisResponse)
async def analyze_image(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(..., description="JPEG, PNG, WEBP, or GIF image file"),
):
    """
    Upload and analyse an image for AI-generation or face-swap manipulation.

    - Accepts: `multipart/form-data` with field name `file`
    - Returns: verdict, confidence score, and per-feature breakdown
    - The uploaded file is deleted automatically after analysis
    """
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported file type '{file.content_type}'. Accepted: {sorted(ALLOWED_IMAGE_TYPES)}",
        )

    path = await save_upload(file)
    schedule_delete(path, background_tasks)

    result = detect_ai_image(path)
    return ImageAnalysisResponse(
        filename=file.filename,
        details=ImageDetails(**result["details"]),
        **{k: v for k, v in result.items() if k != "details"},
    )
