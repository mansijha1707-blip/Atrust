# 🛡️ Atrust Backend

**Multi-Modal Digital Trust Verification System**  
Deepfake video · AI-image detection · Voice clone detection · Phishing/scam text analysis

---

## 📁 Folder Structure

```
atrust-backend/
│
├── main.py              ← FastAPI app entry point (registers all routers)
├── schemas.py           ← Pydantic response models for all endpoints
├── files.py             ← File upload helpers (save, delete, MIME validation)
├── ffmpeg.py            ← FFmpeg stubs for frame/audio extraction
├── report.py            ← Report formatting helpers
├── requirements.txt     ← Python dependencies
├── __init__.py
│
├── routers/             ← One file per analysis modality
│   ├── __init__.py
│   ├── upload.py        ← POST /upload
│   ├── video.py         ← POST /analyze/video
│   ├── image.py         ← POST /analyze/image
│   ├── audio.py         ← POST /analyze/audio
│   └── text.py          ← POST /analyze/text
│
└── uploads/             ← Temporary file storage (auto-created, auto-cleaned)
```

---

## ⚡ Quick Start

### 1. Create a virtual environment

```bash
python -m venv venv

# macOS / Linux
source venv/bin/activate

# Windows
venv\Scripts\activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Run the server

```bash
uvicorn main:app --reload
```

✅ API live at → **http://localhost:8000**  
📖 Swagger UI → **http://localhost:8000/docs**  
📖 ReDoc → **http://localhost:8000/redoc**

---

## 🔗 Endpoints

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `GET` | `/` | Health check |
| `GET` | `/health` | Health check (JSON) |
| `POST` | `/upload` | Upload any media file |
| `POST` | `/analyze/video` | Deepfake video detection |
| `POST` | `/analyze/image` | AI-image / face-swap detection |
| `POST` | `/analyze/audio` | Voice cloning detection |
| `POST` | `/analyze/text` | Phishing / scam text detection |

All `/analyze/*` endpoints accept `multipart/form-data` and handle upload + analysis + cleanup in one request.

---

## 📡 Example Requests & Responses

### POST `/analyze/video`

**curl:**
```bash
curl -X POST http://localhost:8000/analyze/video \
  -F "file=@sample.mp4"
```

**Response:**
```json
{
  "endpoint": "analyze/video",
  "filename": "sample.mp4",
  "status": "fake",
  "confidence": 0.9234,
  "summary": "Significant facial inconsistencies and frame-level artefacts detected — high probability of deepfake manipulation.",
  "details": {
    "facial_inconsistency": 0.8812,
    "temporal_artifacts": 0.7143,
    "lip_sync_mismatch": 0.6509,
    "frame_anomaly_score": 0.7801
  }
}
```

---

### POST `/analyze/image`

**curl:**
```bash
curl -X POST http://localhost:8000/analyze/image \
  -F "file=@photo.jpg"
```

**Response:**
```json
{
  "endpoint": "analyze/image",
  "filename": "photo.jpg",
  "status": "ai_generated",
  "confidence": 0.8872,
  "summary": "Image exhibits GAN fingerprints and noise pattern anomalies — likely AI-generated or manipulated.",
  "details": {
    "face_swap_probability": 0.8234,
    "noise_pattern_anomaly": 0.7651,
    "metadata_tampering": 0.4102,
    "gan_fingerprint_score": 0.8790
  }
}
```

---

### POST `/analyze/audio`

**curl:**
```bash
curl -X POST http://localhost:8000/analyze/audio \
  -F "file=@clip.mp3"
```

**Response:**
```json
{
  "endpoint": "analyze/audio",
  "filename": "clip.mp3",
  "status": "cloned",
  "confidence": 0.9101,
  "summary": "Audio exhibits spectral artefacts and prosody mismatches — high likelihood of TTS or voice-cloning software.",
  "details": {
    "spectral_anomaly": 0.8834,
    "prosody_mismatch": 0.7213,
    "background_noise_inconsistency": 0.5512,
    "voice_similarity_score": 0.8901
  }
}
```

---

### POST `/analyze/text`

**curl:**
```bash
curl -X POST http://localhost:8000/analyze/text \
  -F "text=URGENT: Your UPI account is blocked. Share your OTP immediately to verify KYC."
```

**Response:**
```json
{
  "endpoint": "analyze/text",
  "input_length": 78,
  "status": "phishing",
  "confidence": 0.88,
  "summary": "Message contains 4 high-risk indicator(s): urgent, upi, otp, kyc. Likely a phishing or scam attempt.",
  "details": {
    "detected_keywords": ["urgent", "upi", "otp", "kyc"],
    "impersonation_risk": 0.8234,
    "urgency_score": 0.9101,
    "spam_score": 0.8512
  }
}
```

---

## 🌐 Frontend Integration (your HTML/JS)

Your `script.js` should send requests like this:

```javascript
// ── Analyze a video ────────────────────────────────────────────────
async function analyzeVideo(file) {
  const form = new FormData();
  form.append("file", file);                           // field name must be "file"

  const res = await fetch("http://localhost:8000/analyze/video", {
    method: "POST",
    body: form,
    // Do NOT set Content-Type header — browser sets it automatically with boundary
  });

  if (!res.ok) {
    const err = await res.json();
    console.error("Error:", err.detail);
    return;
  }
  return res.json();
}

// ── Analyze a text message ─────────────────────────────────────────
async function analyzeText(message) {
  const form = new FormData();
  form.append("text", message);                        // field name must be "text"

  const res = await fetch("http://localhost:8000/analyze/text", {
    method: "POST",
    body: form,
  });
  return res.json();
}

// ── Usage ──────────────────────────────────────────────────────────
const fileInput = document.getElementById("fileInput");
fileInput.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  const type = file.type;

  let result;
  if (type.startsWith("video/"))      result = await analyzeVideo(file);
  else if (type.startsWith("image/")) result = await analyzeImage(file);
  else if (type.startsWith("audio/")) result = await analyzeAudio(file);

  console.log(result);
  displayResult(result);     // your UI rendering function
});
```

---

## 🤖 Plugging in Real AI Models

Each detector function is clearly marked with a `# PLUG YOUR REAL MODEL IN HERE` comment block. Replace just the body — the route, schema, and cleanup logic stay unchanged.

### Example — Video (FaceForensics++)

```python
# routers/video.py → detect_deepfake()
from your_model import FaceForensicsClassifier

model = FaceForensicsClassifier.load("weights/ff++.pt")

def detect_deepfake(path: Path) -> dict:
    result = model.predict(str(path))
    is_fake = result.label == "FAKE"
    return {
        "status":     "fake" if is_fake else "authentic",
        "confidence": float(result.score),
        "summary":    result.explanation,
        "details": {
            "facial_inconsistency": result.face_score,
            "temporal_artifacts":   result.temporal_score,
            "lip_sync_mismatch":    result.lip_score,
            "frame_anomaly_score":  result.frame_score,
        },
    }
```

### Recommended Models per Modality

| Modality | Model | Notes |
|----------|-------|-------|
| Video | FaceForensics++, DFDC models | Xception backbone |
| Image | CNNDetection, DIRE, UniversalFakeDetect | Works on GAN + diffusion fakes |
| Audio | RawNet2, AASIST, Resemblyzer | State-of-art anti-spoofing |
| Text | Fine-tuned BERT/RoBERTa, OpenAI Moderation | Custom Indian-scam dataset recommended |

---

## 🔧 CORS

CORS is configured to allow all origins (`*`) for local development.  
Before deploying to production, restrict it in `main.py`:

```python
allow_origins=["https://your-atrust-frontend.com"]
```

---

## ✅ Accepted File Types

| Category | MIME types |
|----------|-----------|
| Image | `image/jpeg`, `image/png`, `image/webp`, `image/gif`, `image/bmp` |
| Video | `video/mp4`, `video/quicktime`, `video/webm`, `video/x-msvideo`, `video/mpeg` |
| Audio | `audio/mpeg`, `audio/wav`, `audio/ogg`, `audio/webm`, `audio/mp4` |

---

## 🚀 Deployment Notes

```bash
# Production (no reload, multiple workers)
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4

# With gunicorn
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```
